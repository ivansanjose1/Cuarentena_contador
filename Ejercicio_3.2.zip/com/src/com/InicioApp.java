package com;

import java.util.Scanner;

public class InicioApp {

    int[] contador;
    char[] letras;
    int palabras;
    int numC = 0;
    int numCaracteresSinBlancos = 0;

    public InicioApp() {
        contador = new int[65536];
        letras = new char[65536];
        palabras = 1;
    }

    public int contarCaracteresTotal(String cadena) {
        int ascii = 0;
        for (int x = 0; x < cadena.length(); x++) {
            char car = cadena.charAt(x);

            ascii = car;
            letras[ascii] = car;

            numC++;

            if (car != ' ') {
                numCaracteresSinBlancos++;
            }
        }
        return ascii;

    }

    public int contarNumeroPalabras(String cadena) {
        char car2 = ' ';
        for (int x = 0; x < cadena.length(); x++) {
            char car = cadena.charAt(x);

            if (car == ' ' && car2 != ' ') {
                palabras++;

            }

            car2 = car;
        }
        return car2;
    }

    public int[] contarTodosCaracteres(String cadena) {
        for (int x = 0; x < cadena.length(); x++) {
            char car = cadena.charAt(x);
            int ascii = car;
            contador[ascii]++;

        }
        return contador;
    }

    public String textoCaracteresTotal(int total) {
        System.out.println("Se han introducido un total de " + numC + " caracteres(contando los espacion en blancos).");
        System.out.println("Se han introducido un total de " + numCaracteresSinBlancos + " caracteres(sin contar los espacion en blancos).");

        return null;

    }

    public String textoNumeroPalabras(int total) {
        System.out.println("Se han ingresado " + palabras + " palabras.");
        return null;
    }

    public String textoTodosCaracteres(int[] total) {
        System.out.println("Las letras que se repiten son:");
        for (int i = 0; i < letras.length; i++) { //Recorro el array y muestro todo.
            if (contador[i] > 0 && letras[i] != ' ') {
                if (contador[i] == 1) {
                    System.out.println("" + letras[i] + "-->" + contador[i] + " vez.");
                } else {
                    System.out.println("" + letras[i] + "-->" + contador[i] + " veces.");
                }
            }
        }

        return null;
    }

    public static void main(String[] args) {
        InicioApp ia = new InicioApp();
        Scanner scan = new Scanner(System.in);
        System.out.println("Introduzca un conjunto de caracteres:");
        String cadena = scan.nextLine();

        ia.textoCaracteresTotal(ia.contarCaracteresTotal(cadena));
        ia.textoNumeroPalabras(ia.contarNumeroPalabras(cadena));
        ia.textoTodosCaracteres(ia.contarTodosCaracteres(cadena));

    }

}
